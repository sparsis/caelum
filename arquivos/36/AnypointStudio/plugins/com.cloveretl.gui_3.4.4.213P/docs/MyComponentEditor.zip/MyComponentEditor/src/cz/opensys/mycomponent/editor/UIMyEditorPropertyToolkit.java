package cz.opensys.mycomponent.editor;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.jface.dialogs.IDialogConstants;
import org.eclipse.jface.viewers.CellEditor;
import org.eclipse.jface.viewers.DialogCellEditor;
import org.eclipse.jface.viewers.ICellEditorValidator;
import org.eclipse.jface.viewers.ILabelProvider;
import org.eclipse.jface.window.Window;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

import cz.opentech.cloveretl.gui.model.ElementBase;
import cz.opentech.cloveretl.gui.propertytoolkit.AbstractUIPropertyToolkit;
import cz.opentech.cloveretl.gui.propertytoolkit.PropertyLabelProvider;

/**
 * Example implementation of simple multi-line editor for component's attribute in clover.GUI plugin. 
 * 
 * @author Martin Zatopek (martin.zatopek@javlinconsulting.cz)
 *         (c) Javlin Consulting (www.javlinconsulting.cz)
 *
 * @created 7.2.2007
 */
public class UIMyEditorPropertyToolkit extends AbstractUIPropertyToolkit {
	
	/**
	 * Validator used in dialog for user input validation. 
	 */
	private ICellEditorValidator validator;
	
    /**
     * This method should return cell editor for this property.
     * One of the most common used cell editor implementation is TextCellEditor.
     * In our example descendant DialogCellEditor is used, which provides cell editor
     * with extension button for custom dialog.  
     */
    public CellEditor getEditor(Composite parent) {
        return new MyCellEditor(parent, getValidator());
    }

    /**
     * This method returns implementation of ILabelProvider. 
     * Using descendant of PropertyLabelProvider is highly recommended
     * for internal GUI features i.e. icons in required attributes.
     */
    public ILabelProvider getLabelProvider() {
        if(labelProvider == null) {
            labelProvider = new PropertyLabelProvider((ElementBase) getEditableValue(), getPropertyDescriptor());
        }
        
        return labelProvider;
    }

    /**
     * This method can return validator for your property value.
     * This implementation checks if the value is a valid integer number.
     */
    public ICellEditorValidator getValidator() {
    	if(validator == null) {
    		validator = new ICellEditorValidator() {
		            public String isValid(Object value) {
		                if (value == null) return null;
		                String s = value.toString();
		                if (s.length() == 0) return null;
		                try {
		                    Integer.parseInt(s);
		                    return null;
		                } catch (NumberFormatException e) {
		                    return "Not an integer number.";
		                }
		            }
    			};
    	}
    	return validator;
    }
}

/**
 * This cell editor is extened by button which opens multi-line dialog.
 * 
 * @author Martin Zatopek (martin.zatopek@javlinconsulting.cz)
 *         (c) Javlin Consulting (www.javlinconsulting.cz)
 *
 * @created 7.2.2007
 */
class MyCellEditor extends DialogCellEditor {

	private ICellEditorValidator validator;
	
	/**
	 * Constructor.
	 */
	public MyCellEditor(Composite parent, ICellEditorValidator validator) {
		super(parent);
		this.validator = validator;
	}

	/**
	 * This is selection handler of dialog button in cell editor.
	 * We only create and open multiline editor with appropriate validator and preseted value. 
	 */
	protected Object openDialogBox(Control cellEditorWindow) {
		String value = getValue() == null ? "" : (String)getValue();
		MultiLineTextEditorDialog dialog = new MultiLineTextEditorDialog(getControl().getShell(), value, validator);
		dialog.create();
		return dialog.open() == Window.OK ? dialog.getValue() : dialog.getValue();
	}
}

/**
 * Simple dialog with one multi-line text editor and error message viewer.
 * 
 * @author Martin Zatopek (martin.zatopek@javlinconsulting.cz)
 *         (c) Javlin Consulting (www.javlinconsulting.cz)
 *
 * @created 7.2.2007
 */
class MultiLineTextEditorDialog extends Dialog {
	
	/**
	 * The input value; the empty string by default.
	 */
	private String value = "";//$NON-NLS-1$

	private ICellEditorValidator validator;
	
	/**
	 * Input text widget.
	 */
	private Text text;

	/**
	 * Error message text widget.
	 */
	private Text errorMessageText;

	/**
	 * Constructor.
	 */
	public MultiLineTextEditorDialog(Shell parentShell, String initialValue, ICellEditorValidator validator) {
		super(parentShell);
		this.validator = validator;
		setShellStyle(getShellStyle() | SWT.RESIZE | SWT.MAX);
		value = initialValue != null ? initialValue : "";
	}
	
	/**
	 * Before closing dialog we only store the result value for later usage.
	 * @see #getValue()
	 */
	protected void buttonPressed(int buttonId) {
		value = buttonId == IDialogConstants.OK_ID ? text.getText() : null;
		super.buttonPressed(buttonId);
	}
	
	/**
	 * Here you can preset shell attributes like window title.
	 */
	protected void configureShell(Shell shell) {
		super.configureShell(shell);
		shell.setText("My multi-line editor");
	}

	/**
	 * After all window widgets are ready to use, you can preset their values. 
	 */
	protected Control createContents(Composite parent) {
		Control control = super.createContents(parent);

		text.setFocus();
		if (value != null) {
			text.setText(value);
			text.selectAll();
		}

		return control;
	}
	
	/**
	 * In this method you have to create all widgets in root composite of dialog.
	 */
	protected Control createDialogArea(Composite parent) {
		// create root composite
		Composite composite = (Composite) super.createDialogArea(parent);
		// create main multi-line text editor
		text = new Text(composite, SWT.MULTI | SWT.BORDER | SWT.V_SCROLL | SWT.H_SCROLL);
		text.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.FILL_BOTH));
		text.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				validateInput();
			}
		});
		// create error message board
		errorMessageText = new Text(composite, SWT.READ_ONLY);
		errorMessageText.setLayoutData(new GridData(GridData.GRAB_HORIZONTAL | GridData.HORIZONTAL_ALIGN_FILL));
		errorMessageText.setBackground(errorMessageText.getDisplay().getSystemColor(SWT.COLOR_WIDGET_BACKGROUND));

		return composite;
	}

	private void validateInput() {
		setErrorMessage(validator.isValid(text.getText()));
	}

	public void setErrorMessage(String errorMessage) {
		errorMessageText.setText(errorMessage == null ? "" : errorMessage); //$NON-NLS-1$
		getButton(IDialogConstants.OK_ID).setEnabled(errorMessage == null);
		errorMessageText.getParent().update();
	}

	/**
	 * Returns the string value typed into this dialog.
	 */
	public String getValue() {
		return value;
	}
}
