/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api;

/**
 * This interface is implemented for every {@link org.mule.api.annotations.Module}
 * and {@link org.mule.api.annotations.Connector} annotated class and its purpose is
 * to define a contract to query the annotated class about its metadata.
 */
public interface MetadataAware
{

    /**
     * Returns the user-friendly name of this module
     */
    public String getModuleName();

    /**
     * Returns the version of this module
     */
    public String getModuleVersion();

    /**
     * Returns the version of the DevKit used to create this module
     */
    public String getDevkitVersion();

    /**
     * Returns the build of the DevKit used to create this module
     */
    public String getDevkitBuild();

    /**
     * Returns the minimun compatible runtime version
     */
    public String getMinMuleVersion();

}
