/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.cache;

import java.io.Serializable;

/**
 * Provides invalidation capability to a {@link CachingStrategy}
 */
public interface InvalidatableCachingStrategy
{

    /**
     * Invalidates all the entries in the cache
     *
     * @throws InvalidateCacheException if there is any error invalidating the cache strategy
     */
    void invalidate();

    /**
     * Invalidates a given entry from the cache if it exists, otherwise ignores it.
     *
     * @param key indicates the cache entry to invalidate. Cannot be null.
     *
     * @throws InvalidateCacheException if there is any error invalidating the cache strategy
     * @throws IllegalArgumentException if key has an invalid value
     */
    void invalidate(Serializable key) throws InvalidateCacheException;
}
