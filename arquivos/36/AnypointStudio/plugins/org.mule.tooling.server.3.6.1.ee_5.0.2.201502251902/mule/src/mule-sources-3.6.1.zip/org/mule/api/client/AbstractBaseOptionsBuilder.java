/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.client;

/**
 * Base options for every operation.
 *
 * @param <BuilderType> builder class
 * @param <OptionsType> options type that this builder creates
 */
public abstract class AbstractBaseOptionsBuilder<BuilderType extends AbstractBaseOptionsBuilder, OptionsType> implements OperationOptionsConfig<BuilderType>
{

    private Long responseTimeout;

    protected AbstractBaseOptionsBuilder()
    {
    }

    public BuilderType responseTimeout(final long timeout)
    {
        this.responseTimeout = timeout;
        return (BuilderType) this;
    }

    /**
     * @return the options object holding all the configuration.
     */
    public abstract OptionsType build();

    /**
     * @return configured timeout. null if no timeout was configured
     */
    protected Long getResponseTimeout()
    {
        return responseTimeout;
    }
}
