/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.client;

/**
 * Base options for every operation executed by {@link org.mule.api.client.MuleClient}
 *
 * Implementations of this class must redefine {@link Object#hashCode()} and {@link java.lang.Object#equals(Object)} since the may be used as key in a map
 */
public interface OperationOptions
{

    /**
     * @return timeout for the operation to execute. May be null if the user didn't configure any.
     */
    Long getResponseTimeout();

}
