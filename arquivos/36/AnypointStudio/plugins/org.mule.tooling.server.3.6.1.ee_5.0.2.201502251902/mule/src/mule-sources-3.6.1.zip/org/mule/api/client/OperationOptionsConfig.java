/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.client;

/**
 *  Common configuration options for all operations
 */
public interface OperationOptionsConfig<BuilderType>
{

    /**
     * @param timeout maximum amount of time to wait for the HTTP response
     * @return the builder
     */
    BuilderType responseTimeout(final long timeout);

}
