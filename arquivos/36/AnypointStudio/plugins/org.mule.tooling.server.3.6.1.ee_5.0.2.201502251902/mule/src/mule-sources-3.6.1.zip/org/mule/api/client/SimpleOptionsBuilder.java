/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.client;

import org.mule.client.SimpleOptions;

/**
 * Most basic options builder that every connector must be able to use for configuration.
 */
public class SimpleOptionsBuilder extends AbstractBaseOptionsBuilder<SimpleOptionsBuilder, OperationOptions>
{

    protected SimpleOptionsBuilder()
    {
    }

    @Override
    public OperationOptions build()
    {
        return new SimpleOptions(getResponseTimeout());
    }

    /**
     * Factory method for the builder.
     *
     * @return a new options builder
     */
    public static SimpleOptionsBuilder newOptions()
    {
        return new SimpleOptionsBuilder();
    }

}
