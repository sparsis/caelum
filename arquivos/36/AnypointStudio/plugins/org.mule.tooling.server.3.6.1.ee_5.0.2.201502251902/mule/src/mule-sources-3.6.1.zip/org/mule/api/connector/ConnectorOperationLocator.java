/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.connector;

import org.mule.MessageExchangePattern;
import org.mule.api.MuleException;
import org.mule.api.client.OperationOptions;
import org.mule.api.processor.MessageProcessor;

/**
 * Locator for a MessageProcessor which is an operation from a Mule connector
 * that fulfils the operation required.
 */
public interface ConnectorOperationLocator
{

    /**
     * Lookup for an operation from a connector
     *
     * @param url the URL that identifies the operation
     * @param operationOptions the options to use to execute the operation
     * @param exchangePattern the exchange pattern to use for the operation
     * @return the operation configured for the url and options
     * @throws MuleException
     */
    MessageProcessor locateConnectorOperation(String url, OperationOptions operationOptions, MessageExchangePattern exchangePattern) throws MuleException;

}
