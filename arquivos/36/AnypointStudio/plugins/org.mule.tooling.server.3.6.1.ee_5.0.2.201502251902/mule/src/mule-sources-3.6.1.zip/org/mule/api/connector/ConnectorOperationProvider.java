/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.connector;

import org.mule.MessageExchangePattern;
import org.mule.api.MuleException;
import org.mule.api.client.OperationOptions;
import org.mule.api.processor.MessageProcessor;

/**
 * Provider of operation for a Mule connector.
 *
 * A Mule connector can provide an implementation of this interface in the registry and mule
 * will use it to create operations using an URL and later executed them.
 *
 * The implementation must be located in the mule registry before the start phase.
 */
public interface ConnectorOperationProvider
{

    /**
     * @param url an URL for creating an operation
     * @return true if the provider can handle the URL, false otherwise
     */
    boolean supportsUrl(String url);

    /**
     * A {@link org.mule.api.processor.MessageProcessor} that contains the behaviour for the URL
     *
     * @param url an URL for creating an operation
     * @param operationOptions the operation options
     * @param exchangePattern exchange pattern to use to execute the request.
     * @return a {@link org.mule.api.processor.MessageProcessor} that fulfills the operation
     * @throws MuleException
     */
    MessageProcessor getMessageProcessor(String url, OperationOptions operationOptions, MessageExchangePattern exchangePattern) throws MuleException;

}
