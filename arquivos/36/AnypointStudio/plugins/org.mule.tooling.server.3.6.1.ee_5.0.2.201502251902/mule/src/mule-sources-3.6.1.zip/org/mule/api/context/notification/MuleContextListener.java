/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.context.notification;

import org.mule.api.MuleContext;

/**
 *  Listens to events raised during the creation of a {@link MuleContext}
 */
public interface MuleContextListener
{

    /**
     * Notifies the creation of a {@link MuleContext} instance right before
     * the initialization.
     *
     * @param context created context
     */
    void onCreation(MuleContext context);

    /**
     * Notifies the initialization of a {@link MuleContext} instance right
     * before the configuration.
     *
     * @param context initialized context
     */
    void onInitialization(MuleContext context);

    /**
     * Notifies the configuration of a {@link MuleContext} instance, after this
     * notification, the context is ready to be used.
     *
     * @param context configured context
     */
    void onConfiguration(MuleContext context);
}
