/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.devkit.capability;


/**
 * This interface is implemented for every {@link org.mule.api.annotations.Module}
 * annotated class, to dynamically query what its capabilities are.
 */
public interface Capabilities
{

    /**
     * Returns true if this module implements such capability
     * 
     * @param capability The capability to test for
     * @return True if it does, false otherwise
     */
    boolean isCapableOf(ModuleCapability capability);
}
