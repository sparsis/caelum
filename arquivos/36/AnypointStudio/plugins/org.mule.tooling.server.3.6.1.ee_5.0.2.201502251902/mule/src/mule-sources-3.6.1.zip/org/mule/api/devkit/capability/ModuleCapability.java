/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.devkit.capability;

import javax.resource.spi.ConnectionManager;

/**
 * Enumeration of possible capabilities of Mule modules. Each capability represents a
 * bit in a bit array. The capabilities of a particular module can be queried using
 * {@link Capabilities}
 */
public enum ModuleCapability
{

    /**
     * This capability indicates that the module implements
     * {@link org.mule.api.lifecycle.Lifecycle}
     */
    LIFECYCLE_CAPABLE(0),

    /**
     * This capability indicates that the module implements {@link ConnectionManager}
     */
    CONNECTION_MANAGEMENT_CAPABLE(1),

    /**
     * This capability indicates that the module implements
     * {@link org.mule.api.oauth.OAuth1Adapter}
     */
    OAUTH1_CAPABLE(2),

    /**
     * This capability indicates that the module implements
     * {@link org.mule.api.oauth.OAuth2Adapter}
     */
    OAUTH2_CAPABLE(3),

    /**
     * This capability indicates that the module implements
     * {@link org.mule.api.adapter.PoolManager}
     */
    POOLING_CAPABLE(4),

    /**
     * This capability indicates that the module implements
     * {@link org.mule.api.oauth.OAuthManager}
     */
    OAUTH_ACCESS_TOKEN_MANAGEMENT_CAPABLE(5);

    private int bit;

    ModuleCapability(int bit)
    {
        this.bit = bit;
    }

    public int getBit()
    {
        return this.bit;
    }

}
