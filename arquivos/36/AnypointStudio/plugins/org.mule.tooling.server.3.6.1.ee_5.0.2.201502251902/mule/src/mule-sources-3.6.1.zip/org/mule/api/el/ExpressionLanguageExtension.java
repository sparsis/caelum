/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.el;

/**
 * Interface used to implement extensions to be used with a Mule Expression Language implementation. Imports,
 * variables, aliases and functions can be added to the Expression Language context as required via the
 * methods available in the {@link ExpressionLanguageContext} instance provided. Note: The context provided,
 * is a static context with no message context available. In order to work with per-evaluation context
 * including the message (including it's payload and properties) and flow/session variables then you should
 * implement {@link ExpressionLanguageFunction}'s and make these available in the context.
 * 
 * @since 3.3
 */
public interface ExpressionLanguageExtension
{

    void configureContext(ExpressionLanguageContext context);

}
