/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.el.datetime;

public interface Time extends Instant
{

    long getMilliSeconds();

    int getSeconds();

    int getMinutes();

    int getHours();

    Time plusMilliSeconds(int add);

    Time plusSeconds(int add);

    Time plusMinutes(int add);

    Time plusHours(int add);

    @Override
    Time withTimeZone(String newTimezone);

    @Override
    Time changeTimeZone(String newTimezone);

    @Override
    Time withLocale(String locale);

}
