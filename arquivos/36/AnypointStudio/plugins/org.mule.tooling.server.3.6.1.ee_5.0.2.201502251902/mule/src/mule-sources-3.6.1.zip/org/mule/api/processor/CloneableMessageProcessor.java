/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.processor;

/**
 *  Adds clone capability to {@link MessageProcessor}
 *  <p/>
 *  NOTE: Lifecycle management is shared with the original {@link MessageProcessor} instance
 */
public interface CloneableMessageProcessor
{

    /**
     * Creates a new instance cloned from the current one
     *
     * @return a not null {@link MessageProcessor}
     */
    MessageProcessor clone();
}
