/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */

package org.mule.api.processor;

/**
 * Adds to a pipeline the ability to dynamically inject a sequence
 * of message processors after initialization.
 *
 * The injected message processors are executed before (pre) of after (post)
 * the ones defined in the flow in the specified order.
 *
 */
public interface DynamicPipeline
{

    /**
     * Provide access to a {@link DynamicPipelineBuilder} that allows modifying
     * the dynamic pipeline injecting message processors and resetting the pipeline
     *
     * @param id dynamic pipeline ID
     * @return a DynamicPipelineBuilder that allows modifying the dynamic pipeline
     * @throws DynamicPipelineException if the pipeline ID is not valid
     */
    DynamicPipelineBuilder dynamicPipeline(String id) throws DynamicPipelineException;

}
