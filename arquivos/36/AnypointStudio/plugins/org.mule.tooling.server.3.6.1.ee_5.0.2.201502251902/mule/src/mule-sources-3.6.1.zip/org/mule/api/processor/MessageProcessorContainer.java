/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.processor;

/**
 * Identifies Constructs that contain Message Processors configured by the user.
 */
public interface MessageProcessorContainer
{

    /**
     * Add the child nodes to the path element tree.
     *
     * @param pathElement
     */
    void addMessageProcessorPathElements(MessageProcessorPathElement pathElement);
}
