/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.processor;

/**
 * @since 3.5.0
 */
public class NamedStageNameSource implements StageNameSource
{

    private final String ownerName;
    private final String stageName;

    public NamedStageNameSource(String ownerName, String stageName)
    {
        this.ownerName = ownerName;
        this.stageName = stageName;
    }

    @Override
    public String getName()
    {
        return String.format("%s.%s", this.ownerName, this.stageName);
    }
}
