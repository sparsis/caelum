/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.processor;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @since 3.5.0
 */
public class SequentialStageNameSource implements StageNameSource
{

    private final String ownerName;
    private final AtomicInteger asyncCount = new AtomicInteger(0);

    public SequentialStageNameSource(String ownerName)
    {
        this.ownerName = ownerName;
    }

    @Override
    public String getName()
    {
        return String.format("%s.%s", this.ownerName, this.asyncCount.addAndGet(1));
    }
}
