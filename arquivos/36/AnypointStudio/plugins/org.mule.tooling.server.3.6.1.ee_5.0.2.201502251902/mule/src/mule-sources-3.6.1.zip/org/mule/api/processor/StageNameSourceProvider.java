/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.processor;

/**
 * This interface defines a contract for a component able to name staged queues
 * through a {@link org.mule.api.processor.StageNameSource} implementation
 *
 * @since 3.5.0
 */
public interface StageNameSourceProvider
{

    /**
     * Provides a {@link org.mule.api.processor.StageNameSource}
     *
     * @return a {@link org.mule.api.processor.StageNameSource}
     */
    public StageNameSource getAsyncStageNameSource();

    /**
     * Returns a {@link org.mule.api.processor.StageNameSource} that
     * takes the given paramter into consideration when generating the name
     *
     * @param asyncName a name to be consider when building the final name
     * @return a {@link org.mule.api.processor.StageNameSource}
     */
    public StageNameSource getAsyncStageNameSource(String asyncName);

}
