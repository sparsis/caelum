/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.api.schedule;


import org.mule.transport.polling.MessageProcessorPollingMessageReceiver;
import org.mule.util.Predicate;

/**
 * <p>
 *     Utility class to create {@link Scheduler} predicates
 * </p>
 */
public class Schedulers
{
    /**
     * @return Predicate used to request the  {@link org.mule.api.registry.MuleRegistry} all the polling {@link org.mule.api.schedule.Scheduler}
     */
    public static Predicate<String> allPollSchedulers()
    {
        return new Predicate<String>()
        {
            @Override
            public boolean evaluate(String s)
            {
                return s.startsWith(MessageProcessorPollingMessageReceiver.POLLING_TRANSPORT + "://");
            }
        };
    }

    /**
     * @return Predicate used to request the  {@link org.mule.api.registry.MuleRegistry} all the polling {@link org.mule.api.schedule.Scheduler}
     *         for a particular {@link org.mule.api.construct.FlowConstruct}
     */
    public static Predicate<String> flowConstructPollingSchedulers(final String flowConstruct)
    {
        return new Predicate<String>()
        {
            @Override
            public boolean evaluate(String s)
            {
                return s.startsWith(MessageProcessorPollingMessageReceiver.POLLING_TRANSPORT + "://" + flowConstruct + "/");
            }
        };
    }
}
