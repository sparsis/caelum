/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.client;

import org.mule.api.client.OperationOptions;

/**
 * Default implementation for {@link org.mule.api.client.OperationOptions}
 */
public class SimpleOptions implements OperationOptions
{

    private final Long responseTimeout;

    public SimpleOptions(Long responseTimeout)
    {
        this.responseTimeout = responseTimeout;
    }
    @Override
    public Long getResponseTimeout()
    {
        return responseTimeout;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }
        if (!(o instanceof SimpleOptions))
        {
            return false;
        }

        SimpleOptions that = (SimpleOptions) o;

        if (responseTimeout == null ? that.responseTimeout != null : !responseTimeout.equals(that.responseTimeout))
        {
            return false;
        }

        return true;
    }

    @Override
    public int hashCode()
    {
        final Long responseTimeout = getResponseTimeout();
        return responseTimeout != null ? responseTimeout.hashCode() : 0;
    }
}
