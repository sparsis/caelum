/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.config;

/**
 * Empty cluster configuration to be used when the instance does not belong to a cluster
 */
public class NullClusterConfiguration implements ClusterConfiguration
{

    @Override
    public String getClusterId()
    {
        return "";
    }

    @Override
    public int getClusterNodeId()
    {
        return 0;
    }
}
