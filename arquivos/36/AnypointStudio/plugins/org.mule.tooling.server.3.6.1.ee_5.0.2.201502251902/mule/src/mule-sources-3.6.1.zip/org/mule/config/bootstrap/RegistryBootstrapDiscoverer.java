/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.config.bootstrap;

import java.util.List;
import java.util.Properties;

/**
 * Allows to discover properties to be used during the bootstrap process.
 * Implementing this interface you will be able to customize which Properties are taken into account at the bootstrap
 * process, and the order they are processed.
 */
public interface RegistryBootstrapDiscoverer
{

    /**
     * Collects the Properties to be used in an ordered way.
     *
     * @return A list of Properties containing the key/value pairs to be used in the bootstrap configuration process.
     * @throws BootstrapException if a problem occurs during the discovery process.
     */
    List<Properties> discover() throws BootstrapException;
}
