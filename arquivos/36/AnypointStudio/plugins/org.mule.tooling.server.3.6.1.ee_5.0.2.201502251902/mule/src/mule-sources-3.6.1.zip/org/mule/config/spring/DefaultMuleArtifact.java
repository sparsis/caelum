/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.config.spring;

import org.mule.common.Capability;
import org.mule.common.MuleArtifact;

public class DefaultMuleArtifact implements MuleArtifact
{
    private Object object;

    public DefaultMuleArtifact(Object object)
    {
        this.object = object;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends Capability> T getCapability(Class<T> clazz)
    {
        if (hasCapability(clazz))
        {
            return (T) object;
        }
        else
        {
            return null;
        }
    }

    @Override
    public <T extends Capability> boolean hasCapability(Class<T> clazz)
    {
        return clazz.isAssignableFrom(object.getClass());
    }

    @Override
    public String toString()
    {
        return object != null ? object.getClass().getName() : "null";
    }
}
