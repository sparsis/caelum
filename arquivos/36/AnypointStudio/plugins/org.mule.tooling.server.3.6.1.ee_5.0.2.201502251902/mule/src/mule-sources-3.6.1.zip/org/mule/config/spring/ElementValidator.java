/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.config.spring;

import org.w3c.dom.Element;

/**
 * Allows validating an {@link Element} prior to parsing it.
 * Implementations are to be reusable and thread-safe
 *
 * @since 3.6.0
 */
public interface ElementValidator
{

    /**
     * Validates the element and throws exception if validation failed
     *
     * @param element the {@link Element} to be validated
     * @throws Exception if the element was not valid
     */
    void validate(Element element);

}
