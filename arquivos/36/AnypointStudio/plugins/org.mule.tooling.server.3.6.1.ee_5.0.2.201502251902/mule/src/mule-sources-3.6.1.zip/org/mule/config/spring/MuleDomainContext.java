/*
 *(c) 2003-2014 MuleSoft, Inc. This software is protected under international copyright
 *law. All use of this software is subject to MuleSoft's Master Subscription Agreement
 *(or other master license agreement) separately entered into in writing between you and
 *MuleSoft. If such an agreement is not in place, you may not use the software.
 */
package org.mule.config.spring;

import org.mule.api.MuleContext;
import org.mule.config.ConfigResource;

import org.springframework.beans.BeansException;

/**
 * A specialization of {@link MuleArtifactContext} for domains
 *
 * @since 3.6.0
 */
final class MuleDomainContext extends MuleArtifactContext
{

    MuleDomainContext(MuleContext muleContext, ConfigResource[] configResources) throws BeansException
    {
        super(muleContext, configResources);
    }

    @Override
    protected Class<MuleDomainBeanDefinitionDocumentReader> getBeanDefinitionDocumentReaderClass()
    {
        return MuleDomainBeanDefinitionDocumentReader.class;
    }

}
